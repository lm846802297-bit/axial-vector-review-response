# Overleaf import instructions

This archive is the referee-response project source at the merged PR #72 revision.

## Files
- `main.tex`: complete referee-response source (renamed from the repository's formal referee-facing TeX filename).
- `references.bib`: the root bibliography used by the referee-response source; it includes the Borah and He neutrino-sector references.
- `JHEP.bst`: bibliography style required by `\\bibliographystyle{JHEP}`.
- `reference_pdf/`: the compiled 58-page PDF for visual comparison; it is not an input dependency.

## Overleaf settings
- Main document: `main.tex`
- Compiler: pdfLaTeX
- Bibliography tool: BibTeX

The source uses `\\bibliography{references}` and `\\bibliographystyle{JHEP}`. No external figure or input files are referenced by `main.tex`.

## Provenance
- Repository: `lm846802297-bit/axial-vector-review-response`
- Merged PR: #72
- Main merge commit: `9ca627c9df7b016af35f11a05fd2a37998d46c60`
- Validated PDF SHA-256: `7d5f3dbb4b959dcb43268a1ebe5ec2cb046cb7502d33244b1e3864b53a6fbc23`
